CUE-GDI-ISO to CHD - Compresse tous types de fichiers disques BIN avec un entête CUE ou GDI ou ISO vers le format CHD (v5). Recherche tous les sous-dossiers et crée des fichiers CHD (v5) dans le dossier dans lequel les fichiers sont placés avec CHDMAN.

Extract CHD to CUE - Décompresse un fichier CHD (V5) en fichier BIN+CUE.
Le format CUE est utilisé par les jeux sur CD. Sur le Raspberry Pi, CHD est pris en charge par TurboGrafx-CD / PC Engine CD, Sega CD / Mega CD et Dreamcast.

Extract CHD to GDI - Décompresse un fichier CHD (V5) vers GDI. (GDI est un format disque pour Dreamcast).
